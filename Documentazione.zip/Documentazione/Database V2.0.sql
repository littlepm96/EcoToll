-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: localhost    Database: pedaggiautostrade
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `amministratore`
--

DROP TABLE IF EXISTS `amministratore`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `amministratore` (
  `Username` varchar(45) NOT NULL,
  `Password` varchar(45) NOT NULL,
  `ChiaveRecupero` varchar(45) NOT NULL,
  `Nome` varchar(45) NOT NULL,
  `Cognome` varchar(45) NOT NULL,
  `LuogoN` varchar(45) NOT NULL,
  `DataN` varchar(45) NOT NULL,
  `Telefono` varchar(45) NOT NULL,
  PRIMARY KEY (`Username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `amministratore`
--

LOCK TABLES `amministratore` WRITE;
/*!40000 ALTER TABLE `amministratore` DISABLE KEYS */;
INSERT INTO `amministratore` VALUES ('lorcar94','lorenzo94','igRTIc','lorenzo','caruso','avezzano','01-08-1994','3270895432'),('ludo196','random01','c1','Ludovico','Di Federico','Pescara','1996-10-01','3270544051'),('Marc','Pos','c2','Marco','Poscente','Antrodoco','1996-04-04','4448729071'),('x','y','c3','x','z','zxy','1996-04-04','0001110001');
/*!40000 ALTER TABLE `amministratore` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `autostrada`
--

DROP TABLE IF EXISTS `autostrada`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `autostrada` (
  `Codice` varchar(45) NOT NULL,
  `Nome` varchar(45) NOT NULL,
  `Tipo` varchar(45) NOT NULL,
  `Amministratore` varchar(45) NOT NULL,
  PRIMARY KEY (`Codice`),
  KEY `Amministratore_idx` (`Amministratore`),
  CONSTRAINT `Amministratore` FOREIGN KEY (`Amministratore`) REFERENCES `amministratore` (`Username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `autostrada`
--

LOCK TABLES `autostrada` WRITE;
/*!40000 ALTER TABLE `autostrada` DISABLE KEYS */;
INSERT INTO `autostrada` VALUES ('A01','A01','pianura','marc'),('a11','pascoli','montagna','marc'),('A24','colle','pianura','marc'),('a34','autostra','montagna','marc'),('A52','avalance','montagna','marc'),('a60','qwerty','montagna','marc'),('a62',' auto62','montagna','marc'),('a999','aa','m','marc');
/*!40000 ALTER TABLE `autostrada` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `casello`
--

DROP TABLE IF EXISTS `casello`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `casello` (
  `codice` varchar(45) NOT NULL,
  `Km` int(11) NOT NULL,
  `Autostrada` varchar(45) NOT NULL,
  `nome` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`codice`),
  KEY `Autostrada_idx` (`Autostrada`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `casello`
--

LOCK TABLES `casello` WRITE;
/*!40000 ALTER TABLE `casello` DISABLE KEYS */;
INSERT INTO `casello` VALUES ('A01C0',0,'A01','qewe'),('A01c01',200,'A01','casello01'),('A01C12',12,'A01',NULL),('A01C20',20,'A01',NULL),('A01C50',500,'A01',NULL),('A34c25',50,'a34','jaòoirfjaò'),('A34c28',12,'A34','0'),('A45c20',200,'A4',NULL),('A52C18',100,'A52','mc'),('A52C19',200,'A52','ww');
/*!40000 ALTER TABLE `casello` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oneri`
--

DROP TABLE IF EXISTS `oneri`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `oneri` (
  `Euro` int(11) NOT NULL,
  `Importo` float NOT NULL,
  `ValoreMin` float NOT NULL,
  `ValoreMax` float NOT NULL,
  PRIMARY KEY (`Euro`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oneri`
--

LOCK TABLES `oneri` WRITE;
/*!40000 ALTER TABLE `oneri` DISABLE KEYS */;
INSERT INTO `oneri` VALUES (1,2.5,5.01,13),(2,3,4.01,5),(3,1.5,3.01,4),(4,1.4,2.01,3),(5,1.3,1.01,2),(6,1,0.01,1);
/*!40000 ALTER TABLE `oneri` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tariffa`
--

DROP TABLE IF EXISTS `tariffa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tariffa` (
  `Categoria` varchar(45) NOT NULL,
  `Tipo` varchar(45) NOT NULL,
  `Valore` float NOT NULL,
  PRIMARY KEY (`Categoria`,`Tipo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tariffa`
--

LOCK TABLES `tariffa` WRITE;
/*!40000 ALTER TABLE `tariffa` DISABLE KEYS */;
INSERT INTO `tariffa` VALUES ('3','Montagna',0.2),('3','pianura',0.14),('4','Montagna',0.2),('4','pianura',0.22),('5','Montagna',0.29),('5','pianura',0.25),('A','Montagna',0.16),('A','pianura',0.15),('B','Montagna',0.15),('B','pianura',0.1);
/*!40000 ALTER TABLE `tariffa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `veicolo`
--

DROP TABLE IF EXISTS `veicolo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `veicolo` (
  `Targa` varchar(45) NOT NULL,
  `Marca` varchar(45) NOT NULL,
  `Modello` varchar(45) NOT NULL,
  `Peso` int(11) NOT NULL,
  `Assi` int(11) NOT NULL,
  `Altezza` int(11) NOT NULL,
  `Anno` int(11) NOT NULL,
  `Categoria` varchar(45) NOT NULL,
  `qtaCO2` float NOT NULL,
  `Oneri` int(11) NOT NULL,
  PRIMARY KEY (`Targa`),
  KEY `Oneri_idx` (`Oneri`),
  CONSTRAINT `Oneri` FOREIGN KEY (`Oneri`) REFERENCES `oneri` (`Euro`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `veicolo`
--

LOCK TABLES `veicolo` WRITE;
/*!40000 ALTER TABLE `veicolo` DISABLE KEYS */;
INSERT INTO `veicolo` VALUES ('AY56ZE','Ford','X-1',2500,2,140,2010,'B',0.7,4),('EX98MS','Fiat','4x4',1250,2,145,1998,'B',0.8,3);
/*!40000 ALTER TABLE `veicolo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'pedaggiautostrade'
--

--
-- Dumping routines for database 'pedaggiautostrade'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-22 12:03:35
